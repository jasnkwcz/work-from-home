import React, { Component } from 'react';
import WorkFromHome from './WorkFromHome';

class App extends Component {
	render() {
		return (
			<div>
				<WorkFromHome />
			</div>
		);
	}
}

export default App;
