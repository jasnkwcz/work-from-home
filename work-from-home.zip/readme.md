App will locally - "npm start" in root directory and access at localhost:9000, or visit hosted site at: http://workfromhome-env-1.eba-mwb43dpw.us-east-1.elasticbeanstalk.com/
To ensure client is up to date, "npm run build" in client directory before running "npm start" in root directory.
Updated 5/6
