Run npm start in both api and client folders to start both servers.
Client page should display a connected message at the bottom of the page for api to be connected.
-5/2
